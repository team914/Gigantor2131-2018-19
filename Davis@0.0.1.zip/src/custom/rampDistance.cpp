// #include "custom/rampDistance.hpp"
// #include <cmath>
// double rampdistancetravled=0;
// double ramptarget(double targetdis,double curentdis,double diriv,int msec,double maxout){
//   double out=0;
//   int changeMsec=4;
//   double loopdis=diriv*msec;
//   if(diriv<maxout){//if it is not at max; a
//     rampdistancetravled+=loopdis;
//   }
//   if(targetdis-(curentdis+loopdis)<rampdistancetravled){//if at the end of the loop it would have hit target
//     changeVar*=-1;
//   }
//   return out;
// }
