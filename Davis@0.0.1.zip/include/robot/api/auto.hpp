#pragma once

#include "api.h"

namespace auton {
  extern pros::Task autonTask;
}  // namespace auton
