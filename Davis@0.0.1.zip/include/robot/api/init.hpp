#ifndef INIT_HPP
#define INIT_HPP

void systemInit();

#endif /* end of include guard: INIT_HPP */
