#ifndef ROUTINES_HPP
#define ROUTINES_HPP
#include "robot/control/auton/selection.hpp"
namespace auton {
  namespace routines {
    void doubleShotFront(void *test);
    namespace red {
      namespace front {
        // void midBoth();
        // void midHold();
        // void midTop();
        // void midBottom();
        void all(selection::Shoots s, selection::Flags f, selection::Options o);
      } // namespace front
      namespace back {
        void midPark();
        void farPark();
        void all(selection::Shoots s, selection::Flags f, selection::Options o);
      } // namespace back
    }   // namespace red
    namespace blue {
      namespace front {
        // void midBoth();
        // void midHold();
        // void midTop();
        // void midBottom();
        // void cloFar();
        void all(selection::Shoots s, selection::Flags f, selection::Options o);
      } // namespace front
      namespace back {
        // void farPark();
        // void midPark();
        void all(selection::Shoots s, selection::Flags f, selection::Options o);
      } // namespace back
    }   // namespace blue
    void skills();
    void testR();
    void testB();
    void defaultSelection();
  } // namespace routines
} // namespace auton
#endif /* end of include guard: ROUTINES_HPP */
