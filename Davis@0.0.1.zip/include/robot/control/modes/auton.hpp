#ifndef AUTON_HPP
#define AUTON_HPP
namespace auton {
  void set_auton(bool b);
  void Task(void *why);
}  // namespace auton
#endif /* end of include guard: AUTON_HPP */
