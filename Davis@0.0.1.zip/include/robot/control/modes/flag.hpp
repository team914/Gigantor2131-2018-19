#pragma once
namespace flag {
void init();
void user();
void deInit();
}  // namespace fla