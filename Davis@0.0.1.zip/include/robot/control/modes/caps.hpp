#pragma once
namespace caps {
  void user();
  void init();
  void deInit();
}  // namespace caps