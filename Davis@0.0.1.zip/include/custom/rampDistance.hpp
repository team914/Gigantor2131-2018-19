// #ifndef RAMPDISTANCE_HPP
// #define RAMPDISTANCE_HPP
// #include "custom/ramping.hpp"
//
// #endif /* end of include guard: RAMPDISTANCE_HPP */
